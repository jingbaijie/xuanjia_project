/*
 * @Descripttion: 
 * @version: 
 * @Author: sueRimn
 * @Date: 2020-04-14 18:58:36
 * @LastEditors: sueRimn
 * @LastEditTime: 2020-04-29 17:04:53
 */
'use strict'
module.exports = {
  NODE_ENV: '"production"',
  Mock: false
}
