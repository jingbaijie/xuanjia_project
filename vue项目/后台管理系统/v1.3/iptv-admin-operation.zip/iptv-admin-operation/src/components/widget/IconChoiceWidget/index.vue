<template>
  <div id='icon_panel' class="icon_content">
    <ul class="icon-list">
      <li>
        <span>
          <i class="el-icon-platform-eleme"></i>
        </span>
      </li>

      <li>
        <span>
          <i class="el-icon-eleme"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-delete-solid"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-delete"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-s-tools"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-setting"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-user-solid"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-user"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-phone"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-phone-outline"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-more"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-more-outline"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-star-on"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-star-off"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-s-goods"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-goods"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-warning"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-warning-outline"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-question"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-info"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-remove"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-circle-plus"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-success"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-error"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-zoom-in"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-zoom-out"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-remove-outline"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-circle-plus-outline"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-circle-check"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-circle-close"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-s-help"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-help"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-minus"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-plus"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-check"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-close"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-picture"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-picture-outline"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-picture-outline-round"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-upload"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-upload2"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-download"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-camera-solid"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-camera"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-video-camera-solid"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-video-camera"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-message-solid"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-bell"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-s-cooperation"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-s-order"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-s-platform"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-s-fold"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-s-unfold"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-s-operation"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-s-promotion"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-s-home"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-s-release"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-s-ticket"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-s-management"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-s-open"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-s-shop"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-s-marketing"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-s-flag"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-s-comment"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-s-finance"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-s-claim"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-s-custom"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-s-opportunity"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-s-data"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-s-check"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-s-grid"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-menu"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-share"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-d-caret"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-caret-left"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-caret-right"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-caret-bottom"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-caret-top"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-bottom-left"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-bottom-right"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-back"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-right"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-bottom"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-top"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-top-left"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-top-right"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-arrow-left"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-arrow-right"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-arrow-down"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-arrow-up"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-d-arrow-left"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-d-arrow-right"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-video-pause"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-video-play"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-refresh"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-refresh-right"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-refresh-left"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-finished"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-sort"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-sort-up"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-sort-down"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-rank"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-view"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-c-scale-to-original"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-date"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-edit"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-edit-outline"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-folder"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-folder-opened"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-folder-add"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-folder-remove"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-folder-delete"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-folder-checked"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-tickets"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-document-remove"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-document-delete"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-document-copy"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-document-checked"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-document"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-document-add"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-printer"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-paperclip"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-takeaway-box"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-search"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-monitor"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-attract"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-mobile"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-scissors"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-umbrella"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-headset"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-brush"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-mouse"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-coordinate"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-magic-stick"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-reading"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-data-line"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-data-board"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-pie-chart"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-data-analysis"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-collection-tag"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-film"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-suitcase"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-suitcase-1"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-receiving"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-collection"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-files"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-notebook-1"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-notebook-2"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-toilet-paper"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-office-building"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-school"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-table-lamp"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-house"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-no-smoking"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-smoking"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-shopping-cart-full"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-shopping-cart-1"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-shopping-cart-2"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-shopping-bag-1"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-shopping-bag-2"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-sold-out"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-sell"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-present"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-box"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-bank-card"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-money"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-coin"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-wallet"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-discount"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-price-tag"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-news"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-guide"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-male"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-female"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-thumb"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-cpu"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-link"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-connection"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-open"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-turn-off"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-set-up"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-chat-round"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-chat-line-round"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-chat-square"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-chat-dot-round"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-chat-dot-square"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-chat-line-square"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-message"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-postcard"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-position"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-turn-off-microphone"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-microphone"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-close-notification"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-bangzhu"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-time"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-odometer"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-crop"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-aim"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-switch-button"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-full-screen"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-copy-document"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-mic"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-stopwatch"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-medal-1"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-medal"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-trophy"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-trophy-1"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-first-aid-kit"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-discover"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-place"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-location"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-location-outline"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-location-information"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-add-location"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-delete-location"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-map-location"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-alarm-clock"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-timer"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-watch-1"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-watch"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-lock"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-unlock"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-key"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-service"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-mobile-phone"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-bicycle"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-truck"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-ship"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-basketball"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-football"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-soccer"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-baseball"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-wind-power"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-light-rain"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-lightning"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-heavy-rain"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-sunrise"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-sunrise-1"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-sunset"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-sunny"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-cloudy"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-partly-cloudy"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-cloudy-and-sunny"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-moon"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-moon-night"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-dish"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-dish-1"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-food"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-chicken"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-fork-spoon"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-knife-fork"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-burger"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-tableware"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-sugar"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-dessert"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-ice-cream"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-hot-water"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-water-cup"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-coffee-cup"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-cold-drink"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-goblet"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-goblet-full"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-goblet-square"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-goblet-square-full"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-refrigerator"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-grape"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-watermelon"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-cherry"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-apple"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-pear"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-orange"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-coffee"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-ice-tea"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-ice-drink"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-milk-tea"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-potato-strips"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-lollipop"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-ice-cream-square"></i>
        </span>
      </li>
      <li>
        <span>
          <i class="el-icon-ice-cream-round"></i>
        </span>
      </li>
    </ul>
    <!-- </el-scrollbar> -->
  </div>
</template>
<script>
import { eventBus } from "@/common/eventBus";

export default {
    data(){
      return {
        name:'IconChoiceWidget',
        selectIcon:''
      }
    },
    methods:{
      liAddEvent(){
        let self= this;
        var pp=document.getElementById('icon_panel');
        var oli =pp.getElementsByTagName('i');
        for(var i=0; i<oli.length; i++){
          (function(j){
            oli[j].onclick = function () {
              self.selectIcon=this.className;
              eventBus.$emit('selIcon',this.className)
            };
          })(i)
        }
      }
    },
    mounted(){
      this.liAddEvent();
    }
}
</script>
<style scoped>
.icon_content {
  background-color: white;
  border-radius: 4px;
  width: 100%;
  height: 20vh;
  overflow: auto;
  position: absolute;
  left: 0px;
  top: -5px;
  z-index: 11111111111111111;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
}
li {
  display: list-item;
  text-align: -webkit-match-parent;
}
ul li i:hover {
  color: #409eff;
}

.icon-list {
  /* overflow: hidden; */
  list-style: none;
  padding-left: 10px !important;
  height: 20vh;

}
ul {
  display: block;
  list-style-type: disc;
  margin-block-start: 1em;
  margin-block-end: 1em;
  margin-inline-start: 0px;
  margin-inline-end: 0px;
  padding-inline-start: 40px;
}
.icon-list li {
  float: left;
  width: 10%;
  text-align: center;
  height: 45px;
  color: #666;
  margin-right: -1px;
  margin-bottom: -1px;
}

.icon-list li span {
  line-height: normal;
  font-family: Helvetica Neue, Helvetica, PingFang SC, Hiragino Sans GB,
    Microsoft YaHei, SimSun, sans-serif;
  color: #99a9bf;
  transition: color 0.15s linear;
}
.icon-list li:after,
.icon-list li span {
  display: inline-block;
  vertical-align: middle;
}
.icon-list li i {
  display: block;
  font-size: 32px;
  margin-bottom: 15px;
  color: #606266;
  transition: color 0.15s linear;
}
.icon-list li .icon-name {
  display: inline-block;
  padding: 0 3px;
  height: 1em;
}
</style>


